

import Card from 'react-bootstrap/Card'
function About(props){

    return (
        
        <Card>
        <Card.Body>
          <Card.Title>About</Card.Title>
          <Card.Subtitle className="mb-2 text-muted">All about Nahid</Card.Subtitle>
          <Card.Text>
            I have done different projects through the WEB222, WEB322, and WEB422 courses during my study at seneca College.
            I am interested to learn React and Angular since many job posting require them.
          </Card.Text>
        </Card.Body>
      </Card>

        )
}
export default About;